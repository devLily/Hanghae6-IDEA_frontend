# 항해 99 frontend, backend 미니 프로젝트 6조

# IDEA

거실,침실 등 장소별로 다른 사용자들이 추천하는 인테리어 용품을 구경하고 나만의 특색있는 소품도 자랑할 수 있는 인테리어 소품 플랫폼 웹 서비스

# 팀원

Frontend (React)

Backend (Node.js)

# 프로젝트 기간

11oct ~ 16oct

# 프로젝트 상세 과정

https://www.notion.so/99-Week-4-Mini-Project-IDEA-670f2d99e4f646a6a74060747a5b4a92

- 슬라이더 사용 => db에서 페이지네이션을 새로 설정해야 하기 때문, post 목록이 1개일때 메인에서 아무것도 보이지 않는다.. 세개면 보이는데..이유를 아직 모르게뜸..

- 메인페이지에서 뿌려지는 모든 데이터의 정렬 기준에 대한 피드백으로 위시의 갯수가 많은대로 정렬을 고민했으나 => db에서 맵핑해야 하므로 플레이스 기준으로 정렬하는 것을 추가구현기능으로 논의
  POST DATA 하나에 해당하는 전체 위시리스트(좋아요) 카운트를 줄 수 있나요? 내려줄 때 정렬해서 응답주실 수 있나요?ㅠㅜ

- 13일 수요일 인증 기능 구현 -> 배포환경에서 테스트를 위한 frontend 중간 배포 완료 http://hanghaeidea.s3-website.ap-northeast-2.amazonaws.com/

# Frontend
