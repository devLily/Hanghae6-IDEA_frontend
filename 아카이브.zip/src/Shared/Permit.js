import React, { Fragment } from "react";

export default function Permit(props) {
    return (
    <Fragment>{props.children}</Fragment>
    );
  }
