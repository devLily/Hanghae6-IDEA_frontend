import React, {Fragment} from "react";

export default function Upload (props) {

    return (
        <Fragment>
            <input type="file"/>
        </Fragment>
    );
}
