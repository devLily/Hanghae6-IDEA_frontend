import React, {Fragment} from "react";
import styled from "styled-components";

export default function Saved(props) {
  return (
    <Fragment>likeList</Fragment>
  );
}
